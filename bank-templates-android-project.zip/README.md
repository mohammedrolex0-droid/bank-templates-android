# بناء ملف APK

المتطلبات: Node.js 18+ و JDK 17 و Android Studio (أو Android SDK).

1) npm install
2) npx cap add android
3) npx cap sync
4) cd android && ./gradlew assembleDebug      (على ويندوز: gradlew.bat assembleDebug)

الملف الناتج:
android/app/build/outputs/apk/debug/app-debug.apk

التعديل لاحقاً: غيّر www/index.html ثم نفّذ  npx cap sync  وأعد الخطوة 4.
